from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "index.html", contexto)


def courses(request):
    contexto={
        "titulo":"Cursos",
        "cursos":[
            {"nome":"Redes de Computadores", "link":"/cursos/ads"},
            {"nome":"Análise e Desenvolvimento de Sistemas", "link":"/cursos/ads"},
            {"nome":"Banco de Dados", "link":"/cursos/bd"},
            {"nome":"Games", "link":"/cursos/games"},
            {"nome":"UX", "link":"/cursos/ux"},
            {"nome":"Arduino", "link":"/cursos/arduino"},
        ]
    }
    return render(request, "courses.html", contexto)


def courses_details_redes(request):
    contexto={
        "titulo":"Cursos",
        "disc_sem1":["Administração de Redes e Sistemas", "Arquitetura de Redes de Computadores","Cabeamento Estruturado","Comunicação e Expressão", "Fundamentos de Sistemas Operacionais", "Introdução à Internet das Coisas - IoT","Programação para Redes"],
        "disc_sem2":["Administração de Redes e Sistemas Operacionais Livres","Ambiente de Desenvolvimento e Operação - DevOps","Gestão de TI","Redes de Longa Distância","Linguagem Brasileira de Sinais - LIBRAS","Routing", "Segurança em Redes e Infraestrutura","Gestão de Projetos"],
        "disc_sem3":["Comunicação de Dados","Diagnóstico e Gerenciamento de Redes","Legislação e Ética","Oficina Projeto Empresa 2 - OPE2","Optativa (Sociedade e Sustentabilidade","Língua Brasileira de Sinais - LIBRAS)","Redes Convergentes","Segurança em Sistemas","Switching"],
        "disc_sem4":["Computação em Nuvem","Comunicações Móveis","Auditoria e Controle de TI","Oficina Projeto Empresa 3 - OPE3","Redes IPV6,Serviços de Redes de Computadores","Tópicos Especiais em Redes de Computadores"]    
    }
    return render(request, "courses_details_redes.html", contexto)


def courses_details_ads(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "courses_details_ads.html")


def courses_details_bd(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "disc_sem1":["Lógica de Programação", "Linguagem de Programação","Fundamentos de Banco de Dados","IoT", "Matemática Aplicada", "Comunicação e Expressão"],
        "disc_sem2":["Análise Exploratória de Dados","Engenharia de Software","Desenvolvimento de Sistemas","Ambiente de Desenvolvimento","Linguagem Brasileira de Sinais - LIBRAS","Linguagem SQL"],
        "disc_sem3":["Business Intelligence","Developing Database","Estrutura de Dados","Data Analytics","OPE1 - Oficina Projeto Empresa 1"],
        "disc_sem4":["Administração de Banco de Dados","Qualidade de Governança de Dados","Segurança de Banco de Dados","Computação Cognitiva","OPE2","Legislação Ética"]

    }
    return render(request, "courses_details_bd.html", contexto)











def cadastro_aluno(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "cadastro_aluno.html")







def courses_details_redes(request):
    return render(request, "courses_details_redes.html")


def form_new_course(request):
    return render(request, "form_new_course.html")



def table_aluno(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "table_aluno.html")


def login(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "login.html")


